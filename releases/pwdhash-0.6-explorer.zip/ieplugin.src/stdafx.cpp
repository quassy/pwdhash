#include "stdafx.h"
 