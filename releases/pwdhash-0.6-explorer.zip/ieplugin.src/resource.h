//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pwdhash.rc
//
#define IDC_ENABLE_PASSWORD_HASHING     102
#define IDC_EXCEPTIONS_TREE             103
#define IDC_GLOBAL_PASSWORD             104
#define IDC_USE_GLOBAL_PASSWORD         105
#define IDC_EXCEPTIONS_LABEL            106
#define IDC_ENTER_PASSWORDS_ON_TOOLBAR  107
#define IDC_F2_MODE                     107
#define IDC_F2_MODE2                    108
#define IDC_RECORD_PASS                 108
#define IDI_ICONRED                     109
#define IDI_ICONGREEN                   110
#define IDS_PROJNAME                    111
#define IDS_WARNING_TITLE               112
#define IDS_DISABLE_HASHING_WARNING_TITLE 112
#define IDS_WARNING_MESSAGE             113
#define IDS_DISABLE_HASHING_WARNING_MESSAGE 113
#define IDS_STATUS_SECURE               114
#define IDS_ALREADY_TYPED_PASSWORD_WARNING_MESSAGE 114
#define IDS_STATUS_INSECURE             115
#define IDS_ALREADY_TYPED_PASSWORD_WARNING_TITLE 115
#define IDM_STATUSBUTTON                116
#define IDS_UNPROTECTED_PASSWORD_WARNING_MESSAGE 116
#define IDD_OPTIONS                     117
#define IDS_UNPROTECTED_PASSWORD_WARNING_TITLE 117
#define IDR_PWDHASH                     118
#define IDS_PROTECT_TEXTFIELD_MESSAGE   118
#define IDR_HTML_STATUSDLG              119
#define IDS_PROTECT_TEXTFIELD_TITLE     119
#define IDD_STATUSDLG                   120
#define IDS_UNPROTECTED_PASSWORD_WARNING_BUTTONS 120
#define IDS_UNPROTECTED_PASSWORD_WARNINGa_BUTTONS 120
#define IDS_DROP_WARNING_TITLE          121
#define IDS_DROP_WARNING_MESSAGE        122
#define IDS_PASTE_WARNING_TITLE         123
#define IDS_PASTE_WARNING_MESSAGE       124
#define IDS_PROTECT_NONPASSWORD_FIELD_WARNING 125
#define IDC_DOMAIN                      1001
#define IDC_PASSWORD_YESNO              1002
#define IDC_HASHING                     1003
#define IDC_HASHING_YESNO               1004
#define IDC_PASSWORD_PIC                1005
#define IDC_EDIT                        1006
#define IDRULES                         1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           121
#endif
#endif
