# PwdHash Sidebar
PwdHash (by Stanford) generates passwords resistant to theft and phishing by hashing a combination of the sites address and your password. It is available as browser extensions (Firefox, Chrome, Opera <12), apps (Android, iOS, Windows), scripts (Ruby, Python) or a simple web page which uses Javascript. 

This version of PwdHash is both a web extension for common browsers as well a simple web page. You can install it as an add-on or just save the whole page locally.